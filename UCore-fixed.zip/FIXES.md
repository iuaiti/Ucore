# Fixes applied

- Added the missing MySQL JDBC driver dependency so `DatabaseManager` can actually connect to `jdbc:mysql://...`.
- Created the plugin data folder before loading or saving config files.
- Hardened GUI click handling so clicks outside the top inventory do not get processed.
- Cleared stale GUI slots when rendering paginated menus.
- Added safer location parsing and null checks.
- Made message sending fall back more safely when a path is missing.
- Tightened a few MiniMessage strings in the default messages file.
